import express from "express";
import axios from "axios";

const app = express();
const port = 3000;
const API_URL = "https://dog.ceo/api/breed/";

app.use(express.static("public"));

app.get("/", (req, res) => {
    res.render("index.ejs", { content: "Waiting for you to choose a dog breed...." });
});

app.post("/get-hound", async (req, res) => {
    try {
        const result = await axios.get(API_URL + "hound/images/random");
        res.render("index.ejs", { content: JSON.stringify(result.data.message) });
    } catch (error) {
        res.render("index.ejs", { content: "Sorry something went wrong" });
    }
});

app.post("/get-corgi", async (req, res) => {
    try {
        const result = await axios.get(API_URL + "corgi/images/random");
        res.render("index.ejs", { content: JSON.stringify(result.data.message) });
    } catch (error) {
        res.render("index.ejs", { content: "Sorry something went wrong" });
    }
});

app.post("/get-pug", async (req, res) => {
    try {
        const result = await axios.get(API_URL + "pug/images/random");
        res.render("index.ejs", { content: JSON.stringify(result.data.message) });
    } catch (error) {
        res.render("index.ejs", { content: "Sorry something went wrong" });
    }
});

app.post("/get-retriever", async (req, res) => {
    try {
        const result = await axios.get(API_URL + "retriever/images/random");
        res.render("index.ejs", { content: JSON.stringify(result.data.message) });
    } catch (error) {
        res.render("index.ejs", { content: "Sorry something went wrong" });
    }
});

app.post("/get-pomeranian", async (req, res) => {
    try {
        const result = await axios.get(API_URL + "pomeranian/images/random");
        res.render("index.ejs", { content: JSON.stringify(result.data.message) });
    } catch (error) {
        res.render("index.ejs", { content: "Sorry something went wrong" });
    }
});

app.listen(port, () => {
    console.log(`Server running on port: ${port}`);
});